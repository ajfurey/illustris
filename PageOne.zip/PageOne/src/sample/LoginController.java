package sample;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.event.ActionEvent;



public class LoginController {
    
    @FXML
    private Button CancelButton;

    @FXML
    public void cancelButtonOnAction(ActionEvent event){


    Stage stage = (Stage) CancelButton.getScene().getWindow();
    stage.close();
    }
}
